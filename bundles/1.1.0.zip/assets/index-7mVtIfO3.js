const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DSzYOS_c.js","./index-C65YkwBy.js","./index-CiVFt8d2.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-C65YkwBy.js";const _=r("Share",{web:()=>t(()=>import("./web-DSzYOS_c.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
