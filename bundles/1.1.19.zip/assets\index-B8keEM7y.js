const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-X72S1cBu.js","./index-SuErxfsm.js","./index-CrH8Rbvf.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-SuErxfsm.js";const _=r("Share",{web:()=>t(()=>import("./web-X72S1cBu.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
