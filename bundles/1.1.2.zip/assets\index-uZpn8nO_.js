const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-EhCY1A6i.js","./index-D8a7yS1M.js","./index-CiVFt8d2.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-D8a7yS1M.js";const _=r("Share",{web:()=>t(()=>import("./web-EhCY1A6i.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
