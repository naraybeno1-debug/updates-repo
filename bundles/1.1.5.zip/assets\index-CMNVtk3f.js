const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CeXiAkuI.js","./index-CXo49aGd.js","./index-D2VAYAE8.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CXo49aGd.js";const _=r("Share",{web:()=>t(()=>import("./web-CeXiAkuI.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
