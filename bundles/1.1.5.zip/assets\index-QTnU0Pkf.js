const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Bx2PyNpF.js","./index-CXo49aGd.js","./index-D2VAYAE8.css"])))=>i.map(i=>d[i]);
import{r as t,_ as r}from"./index-CXo49aGd.js";const o=t("LiveUpdate",{web:()=>r(()=>import("./web-Bx2PyNpF.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
