const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DLEXGjsE.js","assets/index-CNHTL47a.js"])))=>i.map(i=>d[i]);
import{_ as t}from"./index-BiWw_oW7.js";import{registerPlugin as i}from"./index-CNHTL47a.js";const _=i("LiveUpdate",{web:()=>t(()=>import("./web-DLEXGjsE.js"),__vite__mapDeps([0,1])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
