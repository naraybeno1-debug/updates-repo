const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-N4Oz7Vpr.js","./index-spWITZDJ.js","./index-CrH8Rbvf.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-spWITZDJ.js";const _=r("Share",{web:()=>t(()=>import("./web-N4Oz7Vpr.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
