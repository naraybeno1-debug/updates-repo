const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CpcTgF-Y.js","./index-W_nq7Fh6.js","./index-Dj7SoYfE.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-W_nq7Fh6.js";const _=r("Share",{web:()=>t(()=>import("./web-CpcTgF-Y.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
