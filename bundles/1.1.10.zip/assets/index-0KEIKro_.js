const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CDOqi3LE.js","./index-W_nq7Fh6.js","./index-Dj7SoYfE.css"])))=>i.map(i=>d[i]);
import{r as t,_ as r}from"./index-W_nq7Fh6.js";const o=t("LiveUpdate",{web:()=>r(()=>import("./web-CDOqi3LE.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
