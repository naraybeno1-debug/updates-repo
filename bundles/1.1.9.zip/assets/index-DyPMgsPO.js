const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DXVLNEyr.js","./index-DJxtndWZ.js","./index-Cp5BkmQ_.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DJxtndWZ.js";const _=r("Share",{web:()=>t(()=>import("./web-DXVLNEyr.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
