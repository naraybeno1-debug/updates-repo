const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CSMeC0tl.js","./index-DJxtndWZ.js","./index-Cp5BkmQ_.css"])))=>i.map(i=>d[i]);
import{r as t,_ as r}from"./index-DJxtndWZ.js";const o=t("LiveUpdate",{web:()=>r(()=>import("./web-CSMeC0tl.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
