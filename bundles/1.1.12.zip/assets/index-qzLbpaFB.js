const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BgAgkpNS.js","./index-BUcCIXiK.js","./index-DRXYEopb.css"])))=>i.map(i=>d[i]);
import{r as t,_ as r}from"./index-BUcCIXiK.js";const o=t("LiveUpdate",{web:()=>r(()=>import("./web-BgAgkpNS.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
