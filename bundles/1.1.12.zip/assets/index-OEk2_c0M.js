const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-5kbIwcIc.js","./index-BUcCIXiK.js","./index-DRXYEopb.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BUcCIXiK.js";const _=r("Share",{web:()=>t(()=>import("./web-5kbIwcIc.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
