const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DWoxMLAP.js","./index-CoTJDGpY.js","./index-CiVFt8d2.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CoTJDGpY.js";const _=r("Share",{web:()=>t(()=>import("./web-DWoxMLAP.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
