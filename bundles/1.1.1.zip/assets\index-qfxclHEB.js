const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Bmuni-JQ.js","./index-CoTJDGpY.js","./index-CiVFt8d2.css"])))=>i.map(i=>d[i]);
import{r as t,_ as r}from"./index-CoTJDGpY.js";const o=t("LiveUpdate",{web:()=>r(()=>import("./web-Bmuni-JQ.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
