const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-ZvGECX4g.js","./index-ByDxmVY8.js","./index-xBEkPH-l.css"])))=>i.map(i=>d[i]);
import{r as t,_ as r}from"./index-ByDxmVY8.js";const o=t("LiveUpdate",{web:()=>r(()=>import("./web-ZvGECX4g.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
