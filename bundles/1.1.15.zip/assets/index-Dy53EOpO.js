const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Cqo4NDBE.js","./index-ByDxmVY8.js","./index-xBEkPH-l.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-ByDxmVY8.js";const _=r("Share",{web:()=>t(()=>import("./web-Cqo4NDBE.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
