const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-VznfbpCg.js","./index-C7Snazj2.js","./index-CT1M-aKB.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-C7Snazj2.js";const _=r("Share",{web:()=>t(()=>import("./web-VznfbpCg.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
