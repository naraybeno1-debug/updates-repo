const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BSPtD_Kn.js","./index-C7Snazj2.js","./index-CT1M-aKB.css"])))=>i.map(i=>d[i]);
import{r as t,_ as r}from"./index-C7Snazj2.js";const o=t("LiveUpdate",{web:()=>r(()=>import("./web-BSPtD_Kn.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
