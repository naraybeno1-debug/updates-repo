const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Dw29joP2.js","./index-CuC6L5ac.js","./index-CiVFt8d2.css"])))=>i.map(i=>d[i]);
import{r as t,_ as r}from"./index-CuC6L5ac.js";const o=t("LiveUpdate",{web:()=>r(()=>import("./web-Dw29joP2.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
