const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-LHz0WS3N.js","assets/index-Cyz5c2Ih.js","assets/index-BGnsWWTu.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-Cyz5c2Ih.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-LHz0WS3N.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
