const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CoEYC60p.js","assets/index-Cyz5c2Ih.js","assets/index-BGnsWWTu.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Cyz5c2Ih.js";const o=r("Share",{web:()=>t(()=>import("./web-CoEYC60p.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
