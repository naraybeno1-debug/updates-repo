const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DGtBlH9H.js","./index-BbAEiNga.js","./index-BFeZjfwN.css"])))=>i.map(i=>d[i]);
import{r as t,_ as r}from"./index-BbAEiNga.js";const o=t("LiveUpdate",{web:()=>r(()=>import("./web-DGtBlH9H.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
