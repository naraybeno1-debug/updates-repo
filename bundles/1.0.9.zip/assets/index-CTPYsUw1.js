const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DV1YDq15.js","./index-BbAEiNga.js","./index-BFeZjfwN.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BbAEiNga.js";const _=r("Share",{web:()=>t(()=>import("./web-DV1YDq15.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
