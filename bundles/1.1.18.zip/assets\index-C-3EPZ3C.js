const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Cg9Wg826.js","./index-CurkZT5v.js","./index-CrH8Rbvf.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CurkZT5v.js";const _=r("Share",{web:()=>t(()=>import("./web-Cg9Wg826.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
