const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BLuqfK6i.js","./index-CurkZT5v.js","./index-CrH8Rbvf.css"])))=>i.map(i=>d[i]);
import{r as t,_ as r}from"./index-CurkZT5v.js";const o=t("LiveUpdate",{web:()=>r(()=>import("./web-BLuqfK6i.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
