const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DWwZOk45.js","./index-rrRSH-IH.js","./index-DRXYEopb.css"])))=>i.map(i=>d[i]);
import{r as t,_ as r}from"./index-rrRSH-IH.js";const o=t("LiveUpdate",{web:()=>r(()=>import("./web-DWwZOk45.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
