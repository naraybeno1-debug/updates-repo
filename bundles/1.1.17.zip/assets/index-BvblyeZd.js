const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CuyuAhju.js","./index-DfAqTb4K.js","./index-CrH8Rbvf.css"])))=>i.map(i=>d[i]);
import{r as t,_ as r}from"./index-DfAqTb4K.js";const o=t("LiveUpdate",{web:()=>r(()=>import("./web-CuyuAhju.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
