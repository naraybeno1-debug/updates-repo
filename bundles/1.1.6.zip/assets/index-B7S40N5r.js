const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Cz94XK-u.js","./index-DFsmzxOB.js","./index-DzsYEG-w.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DFsmzxOB.js";const _=r("Share",{web:()=>t(()=>import("./web-Cz94XK-u.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
