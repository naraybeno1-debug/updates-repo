const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-9Bp8Qu10.js","./index-CiGk-zYh.js","./index-xBEkPH-l.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CiGk-zYh.js";const _=r("Share",{web:()=>t(()=>import("./web-9Bp8Qu10.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
