const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-s8wVVSxe.js","./index-CiGk-zYh.js","./index-xBEkPH-l.css"])))=>i.map(i=>d[i]);
import{r as t,_ as r}from"./index-CiGk-zYh.js";const o=t("LiveUpdate",{web:()=>r(()=>import("./web-s8wVVSxe.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
