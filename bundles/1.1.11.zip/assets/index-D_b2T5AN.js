const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-I3oFC8wj.js","./index-CxddEoT5.js","./index-Dj7SoYfE.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CxddEoT5.js";const _=r("Share",{web:()=>t(()=>import("./web-I3oFC8wj.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
